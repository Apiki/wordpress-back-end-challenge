<?php

/**
 * Plugin Name: Apiki Favorites
 * Plugin URI: https://apiki.com/plugins/apiki-favorites
 * Description: Um plugin para adicionar posts à lista de favoritos usando a WP REST AP.
 * Version: 1.0.0
 * Author: Reza Rastegarian
 * Author URI: https://Apiki.com
 * License: GPL2
 * Text Domain: apiki-favorites
 * Wordpress: 6.7.1
 * 
 */





/**
 * This function creates a table at first activation to store favorite post records 
 *
 *
 */
function apiki_favorites_create_table()
{
    global $wpdb;

    $table_name = $wpdb->prefix . 'apiki_favorites';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) NOT NULL,
        post_id BIGINT(20) NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_post (user_id, post_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'apiki_favorites_create_table');



/**
 * This function registers favorite-plugin routes to add or remove favorite records
 *
 *
 */
function apiki_favorites_register_routes()
{
    register_rest_route('apiki/v2', '/favorites/', array(
        'methods' => 'POST',
        'callback' => 'apiki_add_to_favorites',
        'permission_callback' => '__return_true',
    ));
    register_rest_route('apiki/v2', '/favorites/', array(
        'methods' => 'DELETE',
        'callback' => 'apiki_remove_from_favorites',
        'permission_callback' => '__return_true',
    ));
    register_rest_route('apiki/v2', '/favorites/', array(
        'methods' => 'GET',
        'callback' => 'apiki_gets_all_favorites',
        'permission_callback' => '__return_true',
    ));
}
add_action('rest_api_init', 'apiki_favorites_register_routes');



/**
 * This function adds a favorite table record
 * 
 * First: we need to login: 
 * POST => http://localhost/wordpress/wp-json/jwt-auth/v1/token
 * {
 * "username": "user",
 * "password": "pass"
 * }
 * then we receive a token
 * Second: sending a header named: Authorization: Bearer {token}
 * POST => http://localhost/wordpress/wp-json/apiki/v2/favorites?post_id=1
 *
 * @param int $post_id The post id adding the favorite table record
 */
function apiki_add_to_favorites($data)
{
    // Checks the user logged-in
    if (is_user_logged_in()) {
        if (!$data['post_id']) {

            return new WP_REST_Response('Post id is required', status: 400);
        }
        global $wpdb;
        $user_id = get_current_user_id();
        $post_id = $data['post_id'];

        $table_name = $wpdb->prefix . 'apiki_favorites';



        // Checks if exists a post according to the post id
        $thePostExists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM wp_posts WHERE ID = %d",
            $post_id
        ));
        if (!$thePostExists) {
            return new WP_REST_Response("There is no record according to the post id", status: 400);
        }


        // Checks whether the post id with the user id received already added or not
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND post_id = %d",
            $user_id,
            $post_id
        ));




        if (!$existing) {
            $wpdb->insert($table_name, array(
                'user_id' => $user_id,
                'post_id' => $post_id,
            ));
        }

        return new WP_REST_Response('Post added to favorites', 200);
    }

    return new WP_REST_Response('User not logged in', 403);
}

/**
 * This function removes a favorite table record
 * 
 * First: we need to login: 
 * POST => http://localhost/wordpress/wp-json/jwt-auth/v1/token
 * {
 * "username": "user",
 * "password": "pass"
 * }
 * then we receive a token
 * Second: sending a header named: Authorization: Bearer {token}
 * DELETE => http://localhost/wordpress/wp-json/apiki/v2/favorites?post_id=1
 * 
 * @param int $post_id The post id removing the favorite table record
 */
function apiki_remove_from_favorites($data)
{
    // Checks the user logged-in
    if (is_user_logged_in()) {
        global $wpdb;
        $user_id = get_current_user_id();
        $post_id = $data['post_id'];

        $table_name = $wpdb->prefix . 'apiki_favorites';

        $wpdb->delete($table_name, array('user_id' => $user_id, 'post_id' => $post_id));

        return new WP_REST_Response('Post removed from favorites', 200);
    }

    return new WP_REST_Response('User not logged in', 403);
}


/**
 * This function gets all favorites by user id
 * 
 * First: we need to login: 
 * POST => http://localhost/wordpress/wp-json/jwt-auth/v1/token
 * {
 * "username": "user",
 * "password": "pass"
 * }
 * 
 * then we receive a token
 * Second: sending a header named: Authorization: Bearer {token}
 * GET => http://localhost/wordpress/wp-json/apiki/v2/favorites
 * 
 */
function apiki_gets_all_favorites()
{
    // Checks the user logged-in
    if (is_user_logged_in()) {
        global $wpdb;
        $user_id = get_current_user_id();

        $table_name = $wpdb->prefix . 'apiki_favorites';

        $results = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT post_id FROM $table_name WHERE user_id = %d",
                $user_id
            )
        );

        return new WP_REST_Response($results, 200);
    }

    return new WP_REST_Response('User not logged in', 403);
}
